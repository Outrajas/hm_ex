Hand-tracker analysis upload bundle

This archive is a compact review package. It contains project-related Colab notebooks with code, Markdown, text outputs, and tracebacks retained; image/HTML/rich-render outputs removed. Historical experiment notebook cells are split in order, each original cell included once.

Also included are the Phase 7 trainer, precompute script, Colab launcher, webcam smoke script, model/runtime implementation files, and the timeline/results reports. No dataset images, MANO assets, checkpoints, videos, credentials, or rendered PNGs are included.

The Phase 7 notebook invokes the trainer source from a Drive bundle; source/phase7_train_temporal.py is the trainer snapshot used by that bundle.

These are source and evidence files for analysis. The split historical notebooks are not standalone runnable notebooks.
